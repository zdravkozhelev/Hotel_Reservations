﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Manager_Hotel_Reservations.Models
{
    public class Class_Id
    {
        [Key]
        public int Id { get; set; }
    }
}
